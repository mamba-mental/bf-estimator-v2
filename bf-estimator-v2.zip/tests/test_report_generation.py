# tests\test_report_generation.py
import unittest
import os
from datetime import datetime
from report_generation import generate_comprehensive_report, save_report

class TestReportGeneration(unittest.TestCase):
    def setUp(self):
        self.sample_progression = [
            {
                'date': '090124',
                'weight': 80,
                'body_fat_percentage': 25,
                'daily_calorie_intake': 2000,
                'tdee': 2500,
                'weekly_caloric_output': 3500,
                'total_weight_lost': 0,
                'lean_mass': 60,
                'fat_mass': 20,
                'muscle_gain': 0,
                'rmr': 1800
            },
            {
                'date': '090824',
                'weight': 79,
                'body_fat_percentage': 24,
                'daily_calorie_intake': 1950,
                'tdee': 2450,
                'weekly_caloric_output': 3500,
                'total_weight_lost': 1,
                'lean_mass': 60.1,
                'fat_mass': 18.9,
                'muscle_gain': 0.1,
                'rmr': 1790
            }
        ]
        self.sample_initial_data = {
            'name': 'John Doe',
            'dob': datetime(1990, 1, 1),
            'gender': 'm',
            'height_feet': 5,
            'height_inches': 10,
            'height_cm': 177.8,
            'goal_weight': 75,
            'goal_bf': 20,
            'activity_level_description': 'Moderate exercise/sports 3-5 days/week',
            'experience_level': 'Intermediate (2-4 years)',
            'protein_intake': 150,
            'workout_type': 'Bodybuilding',
            'workout_days': 4,
            'volume_score': 0.7,
            'intensity_score': 0.8,
            'frequency_score': 0.9,
            'resistance_training': True,
            'is_athlete': False,
            'job_activity': 'light',
            'leisure_activity': 'moderate',
            'is_bodybuilder': False
        }

    def test_generate_comprehensive_report(self):
        report_data = generate_comprehensive_report(self.sample_progression, self.sample_initial_data)
        self.assertIsInstance(report_data, dict)
        self.assertIn('name', report_data)
        self.assertIn('initial_weight', report_data)
        self.assertIn('final_weight', report_data)
        self.assertIn('total_weight_loss', report_data)

    def test_save_report(self):
        report_data = generate_comprehensive_report(self.sample_progression, self.sample_initial_data)
        filename = save_report(report_data, 'John_Doe', 'markdown')
        self.assertTrue(os.path.exists(filename))
        os.remove(filename)  # Clean up after test

if __name__ == '__main__':
    unittest.main()